import 'dotenv/config';
const csv = (value = '') => value.split(',').map(v => v.trim().replace(/\D/g, '')).filter(Boolean);
export const settings = {
  botName: process.env.BOT_NAME || 'MEGAMIND-MD',
  displayName: process.env.DISPLAY_NAME || 'MEGAMIND AI',
  prefix: process.env.PREFIX || '.',
  mode: (process.env.BOT_MODE || 'private').toLowerCase(),
  ownerNumbers: csv(process.env.OWNER_NUMBERS || ''),
  phoneNumber: (process.env.PHONE_NUMBER || '').replace(/\D/g, ''),
  port: Number(process.env.PORT || 3000),
  sessionDir: process.env.SESSION_DIR || './session',
  autoRead: process.env.AUTO_READ === 'true',
  autoTyping: process.env.AUTO_TYPING === 'true',
  welcome: process.env.WELCOME !== 'false',
  goodbye: process.env.GOODBYE !== 'false',
  antiLink: process.env.ANTI_LINK === 'true',
  antiSpam: true,
  themeEmoji: '⚡',
  openAI: {
    apiKey: process.env.OPENAI_API_KEY || '',
    model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
    baseUrl: (process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '')
  }
};
