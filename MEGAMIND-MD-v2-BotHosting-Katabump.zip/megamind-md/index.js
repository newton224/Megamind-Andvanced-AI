import 'dotenv/config';
import fs from 'node:fs/promises';
import express from 'express';
import pino from 'pino';
import qrcode from 'qrcode-terminal';
import makeWASocket, { DisconnectReason, fetchLatestBaileysVersion, useMultiFileAuthState, makeCacheableSignalKeyStore, Browsers } from '@whiskeysockets/baileys';
import { settings } from './settings.js';
import { logger } from './lib/logger.js';
import { loadCommands } from './lib/loader.js';
import { handleMessage } from './lib/handler.js';
import { initStore } from './lib/store.js';

const app = express();
let connected = false;
app.get('/', (_req, res) => res.json({ name: settings.botName, status: connected ? 'connected' : 'starting', uptime: Math.floor(process.uptime()) }));
app.get('/health', (_req, res) => res.status(connected ? 200 : 503).json({ ok: connected, uptime: process.uptime(), memory: process.memoryUsage().rss }));
const server = app.listen(settings.port, '0.0.0.0', () => logger.info(`Health endpoint listening on ${settings.port}`));

let stopping = false, reconnectTimer, sock, reconnectAttempt = 0;
const log = pino({ level: 'silent' });
const commands = await loadCommands();

async function startBot() {
  if (stopping) return;
  await fs.mkdir(settings.sessionDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(settings.sessionDir);
  const { version } = await fetchLatestBaileysVersion();
  sock = makeWASocket({
    version, logger: log, printQRInTerminal: false,
    browser: Browsers.ubuntu(settings.botName),
    auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, log) },
    markOnlineOnConnect: false, syncFullHistory: false,
    generateHighQualityLinkPreview: false, connectTimeoutMs: 60_000,
    defaultQueryTimeoutMs: 60_000, retryRequestDelayMs: 250
  });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const message of messages) {
      try { await handleMessage(sock, message, commands); }
      catch (error) { logger.error({ err: error }, 'Message event failed'); }
    }
  });
  sock.ev.on('group-participants.update', async ({ id, participants, action }) => {
    if (!['add', 'remove'].includes(action)) return;
    const enabled = action === 'add' ? settings.welcome : settings.goodbye;
    if (!enabled) return;
    for (const participant of participants) {
      const text = action === 'add' ? `👋 Welcome @${participant.split('@')[0]} to the group!` : `👋 @${participant.split('@')[0]} has left the group.`;
      await sock.sendMessage(id, { text, mentions: [participant] }).catch(err => logger.warn({ err }, 'Welcome/goodbye message failed'));
    }
  });
  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr) qrcode.generate(qr, { small: true });
    if (connection === 'connecting') logger.info('Connecting to WhatsApp…');
    if (connection === 'open') { connected = true; reconnectAttempt = 0; logger.info({ user: sock.user?.id }, `${settings.botName} connected`); }
    if (connection === 'close') {
      connected = false;
      const code = lastDisconnect?.error?.output?.statusCode;
      logger.warn({ code }, 'WhatsApp connection closed');
      if (code === DisconnectReason.loggedOut) { logger.error('Session logged out. Back up then clear session storage and pair again.'); return; }
      if (!stopping) {
        clearTimeout(reconnectTimer);
        const delay = Math.min(30_000, 2000 * (2 ** Math.min(reconnectAttempt++, 4))) + Math.floor(Math.random() * 1000);
        reconnectTimer = setTimeout(() => startBot().catch(err => logger.error({ err }, 'Reconnect failed')), delay);
      }
    }
  });
  if (!state.creds.registered && settings.phoneNumber) {
    setTimeout(async () => {
      try { const code = await sock.requestPairingCode(settings.phoneNumber); logger.info(`PAIRING CODE: ${code}`); }
      catch (error) { logger.error({ err: error }, 'Pairing-code request failed; use the QR code instead.'); }
    }, 3000);
  }
}

async function shutdown(signal) {
  if (stopping) return;
  stopping = true; connected = false;
  logger.info({ signal }, 'Shutting down');
  clearTimeout(reconnectTimer);
  try { sock?.end(new Error('Process shutdown')); } catch {}
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('unhandledRejection', error => logger.error({ err: error }, 'Unhandled rejection'));
process.on('uncaughtException', error => { logger.fatal({ err: error }, 'Uncaught exception'); shutdown('uncaughtException'); });
await initStore();
await startBot();
