export default {
  name: 'restart', ownerOnly: true,
  async execute({ sock, message, jid }) {
    await sock.sendMessage(jid, { text: '♻️ Restarting MEGAMIND-MD…' }, { quoted: message });
    setTimeout(() => process.exit(0), 700);
  }
};
