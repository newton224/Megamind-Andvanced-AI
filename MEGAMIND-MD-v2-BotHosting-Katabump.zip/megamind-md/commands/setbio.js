export default { name: 'setbio', ownerOnly: true, async execute({ sock, message, args, jid }) {
  const bio = args.join(' ').trim();
  if (!bio) return sock.sendMessage(jid, { text: 'Usage: .setbio <new status>' }, { quoted: message });
  await sock.updateProfileStatus(bio.slice(0, 139));
  await sock.sendMessage(jid, { text: '✅ Profile status updated.' }, { quoted: message });
}};
