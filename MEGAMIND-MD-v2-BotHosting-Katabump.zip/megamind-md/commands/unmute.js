import { requireGroupAdmin } from '../lib/group.js';
export default { name: 'unmute', groupOnly: true, async execute({ sock, message, jid, sender }) {
  await requireGroupAdmin(sock, jid, sender);
  await sock.groupSettingUpdate(jid, 'not_announcement');
  await sock.sendMessage(jid, { text: '🔊 All participants can send messages again.' }, { quoted: message });
}};
