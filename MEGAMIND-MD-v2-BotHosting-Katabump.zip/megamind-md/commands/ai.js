import { settings } from '../settings.js';
export default {
  name: 'ai', aliases: ['ask'],
  async execute({ sock, message, args, jid }) {
    if (!settings.openAI.apiKey) {
      return sock.sendMessage(jid, { text: 'AI is not configured yet. Add OPENAI_API_KEY to your environment variables and restart.' }, { quoted: message });
    }
    const prompt = args.join(' ').trim();
    if (!prompt) return sock.sendMessage(jid, { text: 'Usage: .ai <your question>' }, { quoted: message });
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30000);
    try {
      const response = await fetch(`${settings.openAI.baseUrl}/chat/completions`, {
        method: 'POST', signal: controller.signal,
        headers: { Authorization: `Bearer ${settings.openAI.apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: settings.openAI.model, messages: [{ role: 'user', content: prompt }], max_tokens: 700 })
      });
      if (!response.ok) throw new Error(`AI provider returned HTTP ${response.status}`);
      const result = await response.json();
      const answer = result.choices?.[0]?.message?.content?.trim() || 'No response returned.';
      await sock.sendMessage(jid, { text: answer.slice(0, 4000) }, { quoted: message });
    } finally { clearTimeout(timeout); }
  }
};
