import { requireGroupAdmin, getMention } from '../lib/group.js';
export default { name: 'demote', groupOnly: true, async execute({ sock, message, jid, sender }) {
    await requireGroupAdmin(sock, jid, sender);
    const target = getMention(message);
    if (!target) return sock.sendMessage(jid, { text: 'Mention a member: .demote @user' }, { quoted: message });
    await sock.groupParticipantsUpdate(jid, [target], 'demote');
  }
};
