import os from 'node:os';
import { settings } from '../settings.js';
export default {
  name: 'menu', aliases: ['help'],
  async execute({ sock, message, jid, commands }) {
    const used = process.memoryUsage();
    const secs = Math.floor(process.uptime());
    const runtime = `${Math.floor(secs / 3600)}h ${Math.floor(secs % 3600 / 60)}m ${secs % 60}s`;
    const text = `╭━━━〔 *${settings.displayName}* 〕━━━╮\n` +
      `┃ ⚡ Runtime: ${runtime}\n┃ 🧠 RAM: ${(used.rss / 1024 / 1024).toFixed(1)} MB\n` +
      `┃ 📦 Commands: ${new Set(commands.values()).size}\n┃ 🖥️ Host: ${os.platform()}\n` +
      `┃ 👤 User: ${message.pushName || 'WhatsApp user'}\n╰━━━━━━━━━━━━━━━━━━╯\n\n` +
      `*GENERAL*\n.ping\n.menu\n.ai <question>\n.groupinfo\n\n` +
      `*OWNER*\n.restart\n.shutdown\n.setbio <text>\n.autoread on/off\n.mode public/private\n\n` +
      `*GROUP ADMIN*\n.kick @user\n.promote @user\n.demote @user\n.mute / .unmute\n.tagall / .hidetag\n\n` +
      `_Prefix: ${settings.prefix} | Mode: ${settings.mode}_`;
    await sock.sendMessage(jid, { text }, { quoted: message });
  }
};
