export default {
  name: 'shutdown', ownerOnly: true,
  async execute({ sock, message, jid }) {
    await sock.sendMessage(jid, { text: '🛑 Shutting down MEGAMIND-MD.' }, { quoted: message });
    setTimeout(() => process.exit(0), 700);
  }
};
