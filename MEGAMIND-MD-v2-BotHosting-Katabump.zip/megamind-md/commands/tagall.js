import { requireGroupAdmin } from '../lib/group.js';
export default {
  name: 'tagall', groupOnly: true,
  async execute({ sock, message, jid, args, sender }) {
    const metadata = await requireGroupAdmin(sock, jid, sender);
    if (metadata.participants.length > 100) return sock.sendMessage(jid, { text: 'For group privacy and notification control, tagall is limited to groups of 100 members.' }, { quoted: message });
    const mentions = metadata.participants.map(p => p.id);
    const lines = mentions.map(id => `・@${id.split('@')[0]}`).join('\n');
    await sock.sendMessage(jid, { text: `📣 ${args.join(' ') || 'Group announcement'}\n\n${lines}`, mentions }, { quoted: message });
  }
};
