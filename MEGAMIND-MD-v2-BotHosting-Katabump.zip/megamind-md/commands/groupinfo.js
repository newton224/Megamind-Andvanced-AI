export default { name: 'groupinfo', groupOnly: true, async execute({ sock, message, jid }) {
  const g = await sock.groupMetadata(jid);
  const admins = g.participants.filter(p => p.admin).length;
  await sock.sendMessage(jid, { text: `*${g.subject}*\nMembers: ${g.participants.length}\nAdmins: ${admins}\nDescription: ${g.desc || 'Not set'}` }, { quoted: message });
}};
