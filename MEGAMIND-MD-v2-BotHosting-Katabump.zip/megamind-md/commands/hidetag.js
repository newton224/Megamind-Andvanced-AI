import { requireGroupAdmin } from '../lib/group.js';
export default { name: 'hidetag', groupOnly: true, async execute({ sock, message, jid, args, sender }) {
  const metadata = await requireGroupAdmin(sock, jid, sender);
  if (metadata.participants.length > 100) return sock.sendMessage(jid, { text: 'Hidetag is limited to groups of 100 members.' }, { quoted: message });
  await sock.sendMessage(jid, { text: args.join(' ') || '📢 Group notice', mentions: metadata.participants.map(p => p.id) }, { quoted: message });
}};
