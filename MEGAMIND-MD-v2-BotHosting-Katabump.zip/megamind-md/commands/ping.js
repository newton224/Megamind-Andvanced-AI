export default {
  name: 'ping',
  async execute({ sock, message, jid }) {
    const start = Date.now();
    const sent = await sock.sendMessage(jid, { text: '🏓 Checking response time…' }, { quoted: message });
    await sock.sendMessage(jid, { text: `⚡ Pong: ${Date.now() - start} ms` }, { quoted: sent });
  }
};
