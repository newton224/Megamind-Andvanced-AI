import { settings } from '../settings.js';
export default { name: 'mode', ownerOnly: true, async execute({ sock, message, args, jid }) {
  const value = args[0]?.toLowerCase();
  if (!['public', 'private'].includes(value)) return sock.sendMessage(jid, { text: `Current mode: ${settings.mode}. Use .mode public/private` }, { quoted: message });
  settings.mode = value;
  await sock.sendMessage(jid, { text: `✅ Bot mode set to ${value}.` }, { quoted: message });
}};
