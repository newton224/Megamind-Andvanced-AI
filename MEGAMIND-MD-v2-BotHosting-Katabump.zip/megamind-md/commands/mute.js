import { requireGroupAdmin } from '../lib/group.js';
export default { name: 'mute', groupOnly: true, async execute({ sock, message, jid, sender }) {
  await requireGroupAdmin(sock, jid, sender);
  await sock.groupSettingUpdate(jid, 'announcement');
  await sock.sendMessage(jid, { text: '🔇 Group set to admins-only messaging.' }, { quoted: message });
}};
