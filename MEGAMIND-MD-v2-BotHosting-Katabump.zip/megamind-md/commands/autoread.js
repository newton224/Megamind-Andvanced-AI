import { settings } from '../settings.js';
export default { name: 'autoread', ownerOnly: true, async execute({ sock, message, args, jid }) {
  const value = args[0]?.toLowerCase();
  if (!['on', 'off'].includes(value)) return sock.sendMessage(jid, { text: `Auto-read is ${settings.autoRead ? 'ON' : 'OFF'}. Use .autoread on/off` }, { quoted: message });
  settings.autoRead = value === 'on';
  await sock.sendMessage(jid, { text: `✅ Auto-read ${value.toUpperCase()}.` }, { quoted: message });
}};
