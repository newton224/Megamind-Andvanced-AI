import { requireGroupAdmin, getMention } from '../lib/group.js';
export default { name: 'kick', groupOnly: true, async execute({ sock, message, jid, sender }) {
    await requireGroupAdmin(sock, jid, sender);
    const target = getMention(message);
    if (!target) return sock.sendMessage(jid, { text: 'Mention a member: .kick @user' }, { quoted: message });
    await sock.groupParticipantsUpdate(jid, [target], 'remove');
  }
};
