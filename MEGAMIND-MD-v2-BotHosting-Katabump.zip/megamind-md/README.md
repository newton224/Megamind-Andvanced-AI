# MEGAMIND-MD v2.0

WhatsApp Multi-Device bot built with Node.js 20+ and Baileys. Includes QR/pairing-code login, multi-file auth, reconnect backoff, command plugins, basic group moderation, AI chat, and a health endpoint.

> This is a modular bot foundation, not a claim that every requested third-party downloader or AI media feature is implemented. Do not use it for unsolicited messaging. Automated WhatsApp connections may be restricted by WhatsApp; use a secondary account and comply with its terms.

## Run

1. Install Node.js 20 or 22.
2. Copy `.env.example` to `.env`.
3. Set `PHONE_NUMBER` (international digits, no plus) for pairing-code login and set `OWNER_NUMBERS`. Leave `PHONE_NUMBER` blank to use the terminal QR.
4. Run `npm install` then `npm start`.
5. In WhatsApp open **Linked devices → Link a device** and enter the pairing code, or scan the QR.

The `session/` directory stores login credentials. Never share it or commit it. Keep persistent storage mounted to this directory on a host.

## Deploy on BotHosting.net / Katabump (Pterodactyl-style panel)

These instructions apply to Node.js container panels; labels may differ slightly by host or egg.

1. Create a **Node.js** bot/server using a Node 20 or 22 runtime (not Python).
2. Upload this ZIP through the panel's file manager and extract it into the server's working directory. `package.json` must be in the root beside `index.js`.
3. Set the startup command to `npm start`. If the panel has an install/dependency command, use `npm install`. If it has a startup file field, use `index.js`.
4. Add environment variables from `.env.example` in the panel's Startup/Variables page. Set `PHONE_NUMBER` and `OWNER_NUMBERS` to your own number in international digits. Do not include the `+`. Set `BOT_MODE=private` initially.
5. Ensure the server has persistent files/storage and that `session/` is not cleared on restart/reinstall. If the panel offers a persistent mount, mount it to the project `session` directory and set `SESSION_DIR` to that absolute mount path.
6. Start the server. Read the console and enter the one-time pairing code in WhatsApp → Linked devices, or use the QR shown in a terminal that supports it. Pairing code is printed only once on first login.
7. Restart the server and confirm it reconnects without asking to pair again. If it asks again, the session directory is not persistent or writable.

**Important for shared hosting:** use one running instance only for a given session. Do not run the same session on two servers. Keep the process running; do not use a web-only/short-lived task container. The included `Procfile` is generic; most Pterodactyl panels use the startup command field instead.

## Other hosts

- **VPS:** `npm install && npm start`; use systemd/PM2 and back up `session/`.
- **Docker:** build the included Dockerfile and mount a persistent volume at `/app/session`.
- **Render:** the sample `render.yaml` is a worker configuration; confirm the plan supports persistent disks.
- **Railway/Koyeb/Replit:** configure Node 20+, `npm install`, `npm start`, and persistent storage for `session/`. Availability and free-tier behavior vary.

## Environment variables

| Variable | Meaning |
|---|---|
| `PHONE_NUMBER` | Optional pairing-code number, digits only |
| `OWNER_NUMBERS` | Comma-separated owner numbers |
| `BOT_MODE` | `private` or `public`; keep private during setup |
| `PREFIX` | Command prefix (default `.`) |
| `SESSION_DIR` | Persistent auth folder (default `./session`) |
| `PORT` | Health endpoint port |
| `OPENAI_API_KEY` | Optional API key for `.ai` |
| `OPENAI_MODEL` | Model supported by your provider |
| `OPENAI_BASE_URL` | OpenAI-compatible API base URL |

## Commands

- `.menu`, `.ping`, `.groupinfo`
- `.ai <question>` (requires API key)
- `.restart`, `.shutdown`, `.setbio <text>`, `.autoread on/off`, `.mode public/private` (owner only)
- `.kick @user`, `.promote @user`, `.demote @user`, `.mute`, `.unmute`, `.tagall [message]`, `.hidetag [message]` (group admin + bot admin required; tag features capped at 100 participants)

## Plugins

Create a `.js` file in `plugins/` and export a default command object with `name`, optional `aliases`, and `async execute(context)`. The loader scans `commands/` and `plugins/` at startup. Restart after adding a plugin.

## Health

`GET /` reports connection status and uptime. `GET /health` returns 200 only while WhatsApp is connected. Set your host health check to `/health` only if it expects WhatsApp connectivity; otherwise use `/` during initial pairing.

## Troubleshooting

- **No pairing code:** ensure `PHONE_NUMBER` is digits only, check console logs, and verify the session is not already registered. QR fallback is available.
- **Pairing code expired:** restart once to request a fresh code; do not repeatedly request codes rapidly.
- **Pairing repeats after restart:** persist the full `SESSION_DIR` path and ensure the bot user can write to it.
- **Group command fails:** both the command sender and bot must be group admins.
- **AI fails:** check API key, provider model access, and outbound network access.
- **Reconnect loop:** check host outbound connectivity, Node version, and ensure no duplicate bot process is using the same session.

## Security

Never publish `.env`, `session/`, or pairing codes. Keep private mode until owner numbers are configured. The bot rate-limits commands; group notifications should be used sparingly and with group consent.
